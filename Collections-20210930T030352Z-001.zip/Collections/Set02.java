import java.util.*;
public class Set02
{
    public static void main(String args[])
    {
        HashMap<String, String> m1=new HashMap<String,String>();
        m1.put("ram","hari");
        m1.put("Cisco","barfi");
        m1.put("honeywell","css");
        m1.put("hari","cts");
        String s2="hari";
        getvalues(m1,s2);
    }
    public static void getvalues(HashMap<String,String>m1, String s2)
    {
        ArrayList<String> l1=new ArrayList<String>();
        for(Map.Entry<String, String>m:m1.entrySet())
        {
            int i=0;
            m.getKey();
            m.getValue();
            if(m.getValue().equals(s2))
            l1.add(m.getKey());
            String op[]=new String[l1.size()];
            
            for(i=0;i<=l1.size();i++)
            op[i]=l1.get(i);
            System.out.println(l1);
        }
        
    }
}