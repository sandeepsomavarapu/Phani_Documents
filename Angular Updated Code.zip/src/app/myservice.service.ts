import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateemployee: Employees;
  user:User;
  role:string;
  token=null;

  constructor(private httpService: HttpClient) { }
  
  authenticate(username:any, password:any) {
    return this.httpService
      .post<any>("http://localhost:8586/authenticate", { username, password })
      .pipe(
        map(userData => {
          console.log(userData.token)
          sessionStorage.setItem("username", username);
          let tokenStr = "Bearer " + userData.token;
          sessionStorage.setItem("token", tokenStr);
          console.log("token",sessionStorage.getItem("token"))
          return userData;
        })
      );
  }


  register(username:any, password:any,role:any) {
    alert("Registering as "+role)
    return this.httpService
      .post<any>("http://localhost:8586/register", { username, password,role })
      .pipe(
        map(userData => {
          return userData;
        })
      );
  }
//roles applicant,ustaffadmin,admcommitemember
  isUserLoggedIn() {
    let user = sessionStorage.getItem("username");
    console.log(user);
    console.log(!(user === null));//=,==,===
    return !(user === null);
  }
  isAdmin()
  {
    let role=sessionStorage.getItem("role");
    console.log("ROLE  ..."+role);
    return !(role==="admin")
  }
  logOut() {
    sessionStorage.removeItem("username");
    sessionStorage.removeItem("role");
    sessionStorage.clear();
  }
  public getEmployees() {
    console.log("ins service get employees");//headers
      return this.httpService.get<Employees>("http://localhost:8586/employees/GetAllEmployees");
    }
  public addEmp(addemp: Employees) {
    console.log("ins service add");
    console.log(addemp);
    return this.httpService.post("http://localhost:8586/employees/EmployeeCreation", addemp);
  }
  public update(updateemployee: Employees) {
    this.updateemployee = updateemployee;
  }
  public updateMethod() {
    return this.updateemployee;
  }
  public onUpdate(updatemp: Employees) {
    console.log("ins service update");

    return this.httpService.put("http://localhost:8586/employees/UpdateEmployee", updatemp);
  }
  delete(id: number) {
    console.log("ins service delete");
    return this.httpService.delete("http://localhost:8586/employees/DeleteEmployee/" + id);
  }

}//Promise,Observable(Operators)rxjs
export class Employees {
  id: number;
  name: string;
  salary: number;
  phonenumber: number;
  company: string;
}
export class User {
username:string;
password:string;
role:string;
}